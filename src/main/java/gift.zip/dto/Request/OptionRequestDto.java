package gift.dto.Request;

public record OptionRequestDto(
    String optionName,
    Integer optionQuantity
) {}
