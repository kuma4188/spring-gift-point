package gift.dto.Request;


public record WishRequestDto(
    Long productId,
    int count
) {}
