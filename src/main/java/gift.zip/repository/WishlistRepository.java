package gift.repository;

import gift.model.Wishlist;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WishlistRepository extends JpaRepository<Wishlist, Long> {
    List<Wishlist> findBySiteUserUsernameAndHiddenFalse(String username);
    Page<Wishlist> findBySiteUserUsernameAndHiddenFalse(String username, Pageable pageable);
}
